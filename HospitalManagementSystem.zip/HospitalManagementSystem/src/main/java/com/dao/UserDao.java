package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.entitiy.User;

public class UserDao 
{
	private Connection con;


	public UserDao(Connection con) {
		super();
		this.con = con;
	}
	
	
	public boolean register(User u)
	{
		boolean f=false;
		
		try 
		{
			String query="insert into user(fullname,email,password) values(?,?,?)";
			
			PreparedStatement pstmt=con.prepareStatement(query);
			
			pstmt.setString(1, u.getFullName());
			pstmt.setString(2, u.getEmail());
			pstmt.setString(3, u.getPassword());
			
			int i=pstmt.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		return f;
	}
	
	
	//login validation to check user entered email and pass is correct or not
	
	public User login(String em,String psw)
	{
		User u=null;
		
		try 
		{
			String query="select * from user where email=? and password=?";
			PreparedStatement pstmt=con.prepareStatement(query);
			
			pstmt.setString(1, em);
			pstmt.setString(2, psw);
			
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				u=new User();
				u.setId(rs.getInt(1));
				u.setFullName(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setPassword(rs.getString(4));
				
			}
		}
		catch
		(Exception e) 
		{
			e.printStackTrace();
		}
		
		return u;
	}
	
	
	//code to check the old password
	public boolean checkOldPassword(int userId,String oldPassword)
	{
		boolean f=false;
		
		try 
		{
			String qry="select * from user where id=? and password=?";
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, userId);
			pstmt.setString(2, oldPassword);
			
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				f=true;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return f;
	}
	
	
	//code to change the password
	
	public boolean changePassword(int userId,String newPassword)
	{
		boolean f=false;
		
		try 
		{
			String qry="update user set password=? where id=?";
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setString(1, newPassword);
			pstmt.setInt(2, userId);
			
			int i=pstmt.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return f;
	}
	
	
}
