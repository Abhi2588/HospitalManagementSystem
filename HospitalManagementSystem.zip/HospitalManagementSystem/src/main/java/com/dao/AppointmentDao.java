package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entitiy.Appointment;

public class AppointmentDao 
{
	private Connection con;


	public AppointmentDao(Connection con) {
		super();
		this.con = con;
	}
	
	public boolean addAppointment(Appointment ap)
	{
		boolean f=false;
		
		try 
		{
			String qry="insert into appointment(user_id,fullname,gender,age,appointment_date,email,phone,disease,doctor_id,address,status) values(?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setInt(1, ap.getUserId());
			pstmt.setString(2, ap.getFullName());
			pstmt.setString(3, ap.getGender());
			pstmt.setString(4, ap.getAge());
			pstmt.setString(5, ap.getAppoinDate());
			pstmt.setString(6, ap.getEmail());
			pstmt.setString(7, ap.getPhNo());
			pstmt.setString(8, ap.getDiseases());
			pstmt.setInt(9, ap.getDoctorId());
			pstmt.setString(10, ap.getAddress());
			pstmt.setString(11, ap.getStatus());
			
			int i=pstmt.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return f;
	}
	
	
	//code to get the appointment
	
	public List<Appointment> getAllAppointmentByLoginUser(int userId)
	{
		List<Appointment>list=new ArrayList<Appointment>();
		
		Appointment ap=null;
		
		try 
		{
			String qry="select * from appointment where user_id=?";
			
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setInt(1, userId);
			
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				ap=new Appointment();
				
				ap.setId(rs.getInt(1));
				ap.setUserId(rs.getInt(2));
				ap.setFullName(rs.getString(3));
				ap.setGender(rs.getString(4));
				ap.setAge(rs.getString(5));
				ap.setAppoinDate(rs.getString(6));
				ap.setEmail(rs.getString(7));
				ap.setPhNo(rs.getString(8));
				ap.setDiseases(rs.getString(9));
				ap.setDoctorId(rs.getInt(10));
				ap.setAddress(rs.getString(11));
				ap.setStatus(rs.getString(12));
				
				list.add(ap);
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		
		return list;
		
	}
	
	
	//code to get the appointment in patient doctor dashboard
	
	public List<Appointment> getAllAppointmentByDoctorLogin(int doctorId)
	{
		List<Appointment>list=new ArrayList<Appointment>();
		
		Appointment ap=null;
		
		try 
		{
			String qry="select * from appointment where doctor_id=?";
			
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setInt(1, doctorId);
			
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				ap=new Appointment();
				
				ap.setId(rs.getInt(1));
				ap.setUserId(rs.getInt(2));
				ap.setFullName(rs.getString(3));
				ap.setGender(rs.getString(4));
				ap.setAge(rs.getString(5));
				ap.setAppoinDate(rs.getString(6));
				ap.setEmail(rs.getString(7));
				ap.setPhNo(rs.getString(8));
				ap.setDiseases(rs.getString(9));
				ap.setDoctorId(rs.getInt(10));
				ap.setAddress(rs.getString(11));
				ap.setStatus(rs.getString(12));
				
				list.add(ap);
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		
		return list;
		
	}
	
	
	public Appointment getAllAppointmentById(int id)
	{	
		Appointment ap=null;
		
		try 
		{
			String qry="select * from appointment where id=?";
			
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setInt(1, id);
			
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				ap=new Appointment();
				
				ap.setId(rs.getInt(1));
				ap.setUserId(rs.getInt(2));
				ap.setFullName(rs.getString(3));
				ap.setGender(rs.getString(4));
				ap.setAge(rs.getString(5));
				ap.setAppoinDate(rs.getString(6));
				ap.setEmail(rs.getString(7));
				ap.setPhNo(rs.getString(8));
				ap.setDiseases(rs.getString(9));
				ap.setDoctorId(rs.getInt(10));
				ap.setAddress(rs.getString(11));
				ap.setStatus(rs.getString(12));
				
				
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		
		return ap;
		
	}
	
	
	
	//code to update status
	
	public boolean updateCommentStatus(int id,int doctorId,String comm)
	{
		boolean f=false;
		
		try 
		{
			String qry="update appointment set status=? where id=? and doctor_id=?";
			
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			pstmt.setString(1,comm); 
			pstmt.setInt(2, id);
			pstmt.setInt(3, doctorId);
			
			
			int i=pstmt.executeUpdate();
			
			if(i==1)
			{
				f=true;
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return f;
	}
	
	
	//get all appointment for admin page
	
	public List<Appointment> getAllAppointment()
	{
		List<Appointment>list=new ArrayList<Appointment>();
		
		Appointment ap=null;
		
		try 
		{
			String qry="select * from appointment order by id desc";
			
			PreparedStatement pstmt=con.prepareStatement(qry);
			
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				ap=new Appointment();
				
				ap.setId(rs.getInt(1));
				ap.setUserId(rs.getInt(2));
				ap.setFullName(rs.getString(3));
				ap.setGender(rs.getString(4));
				ap.setAge(rs.getString(5));
				ap.setAppoinDate(rs.getString(6));
				ap.setEmail(rs.getString(7));
				ap.setPhNo(rs.getString(8));
				ap.setDiseases(rs.getString(9));
				ap.setDoctorId(rs.getInt(10));
				ap.setAddress(rs.getString(11));
				ap.setStatus(rs.getString(12));
				
				list.add(ap);
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		
		return list;
		
	}
	
}
